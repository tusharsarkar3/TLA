from TLA.Analysis.table_1 import analysis_table
from TLA.Analysis.table_2 import analysis_table2

def analyse_data():
    analysis_table()
    analysis_table2()

if __name__ == "__main__":
    analysis_table()
    analysis_table2()